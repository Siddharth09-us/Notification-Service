def send(notification):
    print(f"Sending SMS to user {notification.user_id}: {notification.message}")
