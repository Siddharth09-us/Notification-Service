def send(notification):
    print(f"Storing IN-APP message for user {notification.user_id}: {notification.message}")
