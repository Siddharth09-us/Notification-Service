def send(notification):
    print(f"Sending EMAIL to user {notification.user_id}: {notification.subject} - {notification.message}")
